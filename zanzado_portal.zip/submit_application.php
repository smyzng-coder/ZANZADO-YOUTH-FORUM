<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];

    $cv = $_FILES['cv'];
    $certificate = $_FILES['certificate'];

    $cv_path = "uploads/" . basename($cv['name']);
    $cert_path = "uploads/" . basename($certificate['name']);

    move_uploaded_file($cv['tmp_name'], $cv_path);
    move_uploaded_file($certificate['tmp_name'], $cert_path);

    $data = "$name,$email,$cv_path,$cert_path\n";
    file_put_contents("admin/applications.csv", $data, FILE_APPEND);

    echo "Application submitted successfully!";
}
?>