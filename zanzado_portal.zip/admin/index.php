<?php
echo "<h2>Submitted Applications</h2>";
echo "<table border='1'><tr><th>Name</th><th>Email</th><th>CV</th><th>Certificate</th></tr>";
$lines = file("applications.csv");
foreach ($lines as $line) {
    $fields = explode(",", trim($line));
    echo "<tr>";
    foreach ($fields as $field) {
        echo "<td><a href='../$field'>$field</a></td>";
    }
    echo "</tr>";
}
echo "</table>";
?>